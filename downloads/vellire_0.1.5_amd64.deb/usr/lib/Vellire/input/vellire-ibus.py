#!/usr/bin/python3
"""Native IBus adapter. It processes focused input events and retains no text."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

import gi

gi.require_version("IBus", "1.0")
from gi.repository import Gio, GLib, IBus

# A new engine ID lets IBus load this release alongside a legacy engine that
# may still have the previous Rust mapping library mapped in memory.
FLATPAK = os.getenv("FLATPAK_ID") == "io.vellire.desktop"
SNAP = os.getenv("SNAP_NAME") == "vellire"
NAME = "vellire-flatpak-2" if FLATPAK else "vellire-snap-2" if SNAP else "vellire-2"
COMPONENT = "org.freedesktop.IBus." + (
    "VellireFlatpakV2" if FLATPAK else "VellireSnapV2" if SNAP else "VellireV2"
)
NAME_ACQUIRED = {1, 4}  # D-Bus RequestName replies: primary or already owner.
STYLES = {
    "wide": 1, "script": 2, "bold": 3, "italic": 4, "gothic": 5,
    "double-struck": 6, "monospace": 7, "underline": 8, "sans": 9,
    "bold-italic": 10, "bold-script": 11, "bold-gothic": 12, "sans-bold": 13,
    "sans-italic": 14, "sans-bold-italic": 15, "circled": 16, "small-caps": 17,
    "strikethrough": 18, "overline": 19,
    "parenthesized": 20, "squared": 21, "filled-circles": 22,
    "superscript": 23, "subscript": 24, "double-underline": 25,
    "double-overline": 26, "dotted": 27, "ring-above": 28, "wave-below": 29,
    "negative-squared": 30, "upside-down": 31, "acute": 32,
    "grave": 33, "diaeresis": 34, "caron": 35,
    "macron-below": 36, "dot-below": 37, "slash-through": 38,
    "tilde-through": 39,
    "bold-caps": 40, "sans-bold-caps": 41, "bold-underline": 42, "sans-bold-underline": 43,
}
SHORTCUTS = (
    IBus.ModifierType.CONTROL_MASK | IBus.ModifierType.MOD1_MASK
    | IBus.ModifierType.MOD4_MASK | IBus.ModifierType.SUPER_MASK
    | IBus.ModifierType.HYPER_MASK | IBus.ModifierType.META_MASK
)
TEXT_PURPOSES = {IBus.InputPurpose.FREE_FORM, IBus.InputPurpose.ALPHA, IBus.InputPurpose.NAME, IBus.InputPurpose.URL}


class Preferences:
    def __init__(self, path):
        self.path = path
        self.identity = None
        self.style = 0
        self.skip_address_fields = False

    def active_style(self, purpose):
        try:
            stat = self.path.stat()
            identity = (stat.st_ino, stat.st_mtime_ns, stat.st_size)
            if identity != self.identity:
                prefs = json.loads(self.path.read_text(encoding="utf-8"))
                self.style = STYLES.get(prefs["style"], 0) if prefs["enabled"] is True else 0
                self.skip_address_fields = prefs.get("skipAddressFields") is True
                self.identity = identity
        except (OSError, ValueError, TypeError, KeyError):
            self.style = 0
            self.identity = None
        return 0 if purpose == IBus.InputPurpose.URL and self.skip_address_fields else self.style


def connect_bus():
    if (FLATPAK or SNAP) and not (os.getenv("IBUS_ADDRESS_FILE") or os.getenv("IBUS_ADDRESS")):
        host_home = Path(os.getenv("SNAP_REAL_HOME") or Path.home())
        config = Path(os.getenv("HOST_XDG_CONFIG_HOME") or host_home / ".config")
        machine_id = Path("/etc/machine-id").read_text().strip()
        display = os.getenv("WAYLAND_DISPLAY")
        if display:
            name = f"{machine_id}-unix-{Path(display).name}"
        else:
            host, _, number = os.getenv("DISPLAY", ":0").partition(":")
            name = f"{machine_id}-{host or 'unix'}-{number.split('.')[0]}"
        # The host daemon's PID is outside Flatpak's PID namespace.
        # Pass its socket address directly so IBus can connect to it.
        try:
            for line in (config / "ibus" / "bus" / name).read_text().splitlines():
                if line.startswith("IBUS_ADDRESS=unix:"):
                    os.environ["IBUS_ADDRESS"] = line.removeprefix("IBUS_ADDRESS=")
                    break
        except OSError:
            pass
    IBus.init()
    bus = IBus.Bus.new()
    if not bus.is_connected():
        raise RuntimeError("Start IBus in your desktop session, then try again.")
    return bus


def selected(bus):
    engine = bus.get_global_engine()
    return engine is not None and engine.get_name() == NAME


def gnome_settings(name):
    source = Gio.SettingsSchemaSource.get_default()
    if source is not None and source.lookup(name, True) is not None:
        return Gio.Settings.new(name)
    return None


def add_gnome_input_source():
    settings = gnome_settings("org.gnome.desktop.input-sources")
    if settings is None:
        return False
    sources = settings.get_value("sources").unpack()
    source = ("ibus", NAME)
    legacy = ("ibus", "vellire")
    if source in sources:
        updated = [entry for entry in sources if entry != legacy]
    elif legacy in sources:
        updated = [source if entry == legacy else entry for entry in sources]
    else:
        updated = [*sources, source]
    if updated != sources and settings.is_writable("sources"):
        changed = settings.set_value("sources", GLib.Variant("a(ss)", updated))
        Gio.Settings.sync()
        return changed
    return False


def install_shortcuts(executable):
    schema = "org.gnome.settings-daemon.plugins.media-keys"
    settings = gnome_settings(schema)
    if settings is None:
        raise RuntimeError("Global shortcuts require GNOME keyboard settings.")
    key = "custom-keybindings"
    entries = list(settings.get_strv(key))
    conflicts = []
    for action, letter in (("start", "s"), ("stop", "t")):
        path = f"/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/vellire-{action}/"
        binding = f"<Alt>{letter}"
        if any(
            item != path and Gio.Settings.new_with_path(schema + ".custom-keybinding", item)
            .get_string("binding").lower() == binding.lower()
            for item in entries
        ):
            conflicts.append(f"Alt+{letter.upper()}")
            continue
        shortcut = Gio.Settings.new_with_path(schema + ".custom-keybinding", path)
        shortcut.delay()
        shortcut.set_string("name", f"Vellire: {action.capitalize()} styling")
        shortcut.set_string("command", f"{shlex.quote(str(executable))} --{action}-styling")
        shortcut.set_string("binding", binding)
        shortcut.apply()
        if path not in entries:
            entries.append(path)
    if not settings.set_strv(key, entries):
        raise RuntimeError("GNOME could not save Vellire’s global shortcuts.")
    Gio.Settings.sync()
    if conflicts:
        raise RuntimeError(f"Global shortcut already assigned: {', '.join(conflicts)}.")


def activate(args):
    deadline = time.monotonic() + 6
    while True:
        try:
            bus = connect_bus()
            break
        except RuntimeError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.25)
    source_added = False
    if selected(bus):
        if not args.gnome or not add_gnome_input_source():
            return
        source_added = True
    installed = any(engine.get_name() == NAME for engine in bus.list_engines())
    if not installed and not bus.name_has_owner(COMPONENT):
        subprocess.Popen(
            [sys.executable, __file__, "--register", "--preferences", str(args.preferences),
             "--library", str(args.library)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    deadline = time.monotonic() + 5
    selected_since = None
    while time.monotonic() < deadline:
        if installed or bus.name_has_owner(COMPONENT):
            if args.gnome and not source_added:
                add_gnome_input_source()
                source_added = True
            if not selected(bus):
                selected_since = None
                bus.set_global_engine(NAME)
            elif selected_since is None:
                selected_since = time.monotonic()
            elif time.monotonic() - selected_since >= 0.6:
                return
        time.sleep(0.1)
    raise RuntimeError("IBus could not keep Vellire selected. Choose Vellire in your desktop’s input source menu, then retry.")


def run(args):
    prefs = Preferences(args.preferences)
    core = ctypes.CDLL(str(args.library.resolve()))
    style_key = core.vellire_style_key
    style_key.argtypes = (ctypes.c_uint32, ctypes.c_uint32)
    style_key.restype = ctypes.c_uint32

    class Engine(IBus.EngineSimple):
        __gtype_name__ = "VellireEngine"

        def do_process_key_event(self, keyval, keycode, state):
            purpose, hints = self.get_content_type()
            if purpose not in TEXT_PURPOSES or hints & IBus.InputHints.PRIVATE:
                return False

            # Give IBus compose and Unicode-entry sequences first refusal.
            if IBus.EngineSimple.do_process_key_event(self, keyval, keycode, state):
                return True

            if state & (SHORTCUTS | IBus.ModifierType.RELEASE_MASK | IBus.ModifierType.FORWARD_MASK):
                return False

            character = IBus.keyval_to_unicode(keyval)
            styled = style_key(prefs.active_style(purpose), ord(character)) if character else 0
            if not styled:
                return False

            text = chr(styled & 0x1fffff)
            if mark := styled >> 21:
                text += chr(mark)
            self.commit_text(IBus.Text.new_from_string(text))
            return True

    bus = connect_bus()
    if bus.request_name(COMPONENT, IBus.BusNameFlag.DO_NOT_QUEUE) not in NAME_ACQUIRED:
        if args.register:
            return
        raise RuntimeError("The Vellire IBus name is already in use.")
    factory = IBus.Factory.new(bus.get_connection())
    factory.add_engine(NAME, Engine.__gtype__)
    if args.register:
        component = IBus.Component.new(COMPONENT, "Live Unicode styles", "0.1.5", "", "", "", "", "")
        component.add_engine(IBus.EngineDesc.new(
            NAME, "Vellire", "Live Unicode styles", "en", "", "", "", "default"
        ))
        if not bus.register_component(component):
            raise RuntimeError("IBus rejected the Vellire component.")
    bus.connect("disconnected", lambda *_: IBus.quit())
    IBus.main()
    factory.destroy()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preferences", type=Path, required=True)
    parser.add_argument("--library", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--register", action="store_true", help="Register directly with the current IBus session.")
    mode.add_argument("--activate", action="store_true", help="Select Vellire in the current IBus session.")
    mode.add_argument("--status", action="store_true", help="Report whether IBus and Vellire are available.")
    mode.add_argument("--install-shortcuts", type=Path, help="Register the GNOME keyboard shortcuts.")
    parser.add_argument("--gnome", action="store_true", help="Add Vellire to GNOME input sources.")
    try:
        args = parser.parse_args()
        if args.install_shortcuts:
            install_shortcuts(args.install_shortcuts)
        elif args.activate:
            activate(args)
        elif args.status:
            print("selected" if selected(connect_bus()) else "ready")
        else:
            run(args)
    except (OSError, RuntimeError) as error:
        sys.exit(str(error))
